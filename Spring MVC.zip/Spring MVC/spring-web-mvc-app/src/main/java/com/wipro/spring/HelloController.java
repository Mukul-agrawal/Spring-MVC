package com.wipro.spring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.spring.model.Employ;

@Controller
public class HelloController {

	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		String msgData = "Welcome to Spring Web MVC Apps";
		ModelAndView mav = new ModelAndView();
		mav.setViewName("welcome");
		mav.addObject("msg", msgData);
		return mav;
	}
	
	@RequestMapping("/employ")
	public ModelAndView getEmploy() {
		Employ employ=new Employ(1001,"Raaja",45000.25);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("show-employ");
		mav.addObject("emp", employ);
		return mav;
	}

}

package com.wipro.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbMvcAppOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMvcAppOneApplication.class, args);
	}

}

package com.wipro.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbWebAppOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbWebAppOneApplication.class, args);
	}

}

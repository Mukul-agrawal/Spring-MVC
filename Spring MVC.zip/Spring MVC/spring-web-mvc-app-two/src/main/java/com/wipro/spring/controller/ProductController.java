package com.wipro.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.spring.model.Product;

@Controller
@RequestMapping("/Product")
public class ProductController {

	private static List<Product> productList = new ArrayList<Product>();

	static {

		Product p1 = new Product(1001, "Fan", 2500.25);
		Product p2 = new Product(1002, "Lappy", 45000.25);
		Product p3 = new Product(1003, "Mobile", 65000.25);
		Product p4 = new Product(1004, "Chair", 15000.25);

		productList.add(p1);
		productList.add(p2);
		productList.add(p3);
		productList.add(p4);
	}

	@RequestMapping("/all-products")
	public ModelAndView getAllProducts(ModelAndView mav) {
		/*
		 * Product p1 = new Product(1001, "Fan", 2500.25); Product p2 = new
		 * Product(1002, "Lappy", 45000.25); Product p3 = new Product(1003, "Mobile",
		 * 65000.25); Product p4 = new Product(1004, "Chair", 15000.25);
		 * 
		 * productList.add(p1); productList.add(p2); productList.add(p3);
		 * productList.add(p4);
		 */

		mav.setViewName("show-products");
		mav.addObject("products", productList);
		return mav;
	}

	/*
	 * @RequestMapping("/add-product") public String saveProduct(@RequestParam("id")
	 * int id, @RequestParam("name") String name,
	 * 
	 * @RequestParam("price") double price) { Product product = new Product(id,
	 * name, price); productList.add(product); // return "add-product-info"; return
	 * "redirect:/Product/all-products"; }
	 */

	@RequestMapping("/add-product")
	public String saveProduct(@ModelAttribute("product") Product product) {

		productList.add(product);
//		return "add-product-info";
		return "redirect:/Product/all-products";
	}

}
